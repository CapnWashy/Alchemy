﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using com.calitha.commons;
using com.calitha.goldparser;


namespace Alchemy
{
    
    public partial class Form1 : Form
    {
        
        MyParser parser; 
        public Form1()
        {
            InitializeComponent();
            parser = new MyParser("Alchemy.cgt",listBox1);
        }
       

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        public void Button1_Click(object sender, EventArgs e)
        {
            data input1 = new data(richTextBox1.Text);
            listBox1.Items.Clear();
            parser.Parse(richTextBox1.Text);
        }
       
        
        public void Label2_Click(object sender, EventArgs e)
        {

        }

        public void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
    public class data
    {
        public string textData1 { get; set; }
        public data(string textData1)
        {
            textData1 = textData1;
        }

    }
}
