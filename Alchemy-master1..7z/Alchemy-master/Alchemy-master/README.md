# Alchemy
Alchemy is a language designed for the common man. Alchemy is made for the typist, the elitist, the show-off, the child, the elder, the simple. Alchemy is the programming language for the ‘every’ in ‘everyone’. Alchemy is the tie between the beginner, and the master. 
